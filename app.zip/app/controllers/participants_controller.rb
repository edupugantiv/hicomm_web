class ParticipantsController <ApplicationController 
end 