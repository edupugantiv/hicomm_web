class LeadGroup < Request
end 