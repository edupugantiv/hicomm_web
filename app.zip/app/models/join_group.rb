class JoinGroup < Request 
end 