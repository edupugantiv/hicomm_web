class JoinProject < Request
end 