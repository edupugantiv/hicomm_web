$(document).ready(function() {
	$(".home-page-messages-list").scrollTop(1000000);	
	$(".messages-list").scrollTop(1000000);	
});

