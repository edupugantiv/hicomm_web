class AuthenticationCode < ActiveRecord::Base
end
