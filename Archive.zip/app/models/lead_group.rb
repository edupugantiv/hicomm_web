class LeadGroup < Request
end 