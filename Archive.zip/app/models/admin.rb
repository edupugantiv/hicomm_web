class Admin < User
end 