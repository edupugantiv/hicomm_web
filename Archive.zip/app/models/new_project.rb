class NewProject < Request
end 