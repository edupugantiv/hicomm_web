class NewUser < Request
end 