class NewGroup < Request
end 