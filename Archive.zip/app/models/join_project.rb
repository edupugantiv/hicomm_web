class JoinProject < Request
end 