class JoinGroup < Request 
end 