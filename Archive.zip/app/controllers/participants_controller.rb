class ParticipantsController <ApplicationController 
end 