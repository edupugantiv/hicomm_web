$(document).ready(function() {
	$(".home-page-messages-list").scrollTop(1000);	
	$(".messages-list").scrollTop(1000);	
});

